# tbl_front-end
Trabalho de Front-End sobre hacks para CS GO
Esse trabalho não possui downloads, e **não tem intuito de divulgar hacks para Counter Strike-Global Ofensive**, é apenas o tema gerado pelos alunos Alisson e Wesley para seu trabalho de Front-End, não há realmente downloads e nem terá!